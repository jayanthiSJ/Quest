**MERN Boilerplate** is just a minimal boilerplate for a MERN based webapp.

---
**Useful Commands**
 - npm start - to start your webapp (ensure that your mongo server is running before you start your boilerplate)
